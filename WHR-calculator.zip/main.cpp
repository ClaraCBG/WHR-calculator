#include <iostream>
using namespace std;

int main() {
 float hip, waist, WHR;
 cin >> waist >> hip;

 WHR= waist/hip;
 cout <<WHR;
 
  return 0;
}
